<?php
    /**
     * Created by PhpStorm.
     * User: Administrator
     * Date: 13-11-2018
     * Time: 11:29 AM
     * Since: 1.0.0
     * Updated: 1.0.0
     */

    if ( !function_exists( 'st_search_form_new' ) ) {
        function st_search_form_new( $attr, $content = false )
        {

        }
    }