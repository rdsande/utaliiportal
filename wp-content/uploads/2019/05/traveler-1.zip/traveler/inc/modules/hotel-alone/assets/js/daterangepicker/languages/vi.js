/**
 * Created by Administrator on 9/27/2016.
 */
var locale_daterangepicker = {
    direction: 'ltr',
    applyLabel: 'Đồng Ý',
    cancelLabel: 'Hủy',
    fromLabel: 'Từ',
    toLabel: 'Đến',
    customRangeLabel: 'Tùy chỉnh',
    daysOfWeek: ['CN', 'T2', 'T3', 'T4', 'T5', 'T6','T7'],
    monthNames: ['Tháng một', 'Tháng hai', 'Tháng 3', 'Tháng tư', 'Tháng năm', 'Tháng sáu', 'Tháng bảy', 'Tháng tám', 'Tháng chín', 'Tháng mười', 'Tháng mười một', 'Tháng mười hai'],
    firstDay: 1,
    today: 'Hôm nay'
};