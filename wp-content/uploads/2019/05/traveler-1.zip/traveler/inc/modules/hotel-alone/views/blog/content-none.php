<div class="alert alert-warning">
    <strong><?php esc_html_e('Warning!', ST_TEXTDOMAIN); ?></strong>  <?php esc_html_e('Nothing Found', ST_TEXTDOMAIN); ?>
</div>