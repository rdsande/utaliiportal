<?php
/**
 * Created by PhpStorm.
 * User: me664
 * Date: 3/17/15
 * Time: 6:44 PM
 */
get_template_part('search-cars');