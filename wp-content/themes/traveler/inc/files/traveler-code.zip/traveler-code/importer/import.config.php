<?php 
$st_over_menus = array(
    "Main Menu" => "primary",
);
$homepage_default="Home Layout Default | Traveler";
$homepost_default="";